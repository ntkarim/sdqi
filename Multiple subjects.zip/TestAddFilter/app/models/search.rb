class Search < ActiveRecord::Base


self.table_name = "country_data"


end
